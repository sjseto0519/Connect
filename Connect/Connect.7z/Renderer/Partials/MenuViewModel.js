﻿var MenuViewModel = function () {

    var self = this;



    return self;

}

module.exports = MenuViewModel;