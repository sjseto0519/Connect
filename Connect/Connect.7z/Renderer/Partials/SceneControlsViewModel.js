﻿var SceneControlsViewModel = function () {

    var self = this;

    self.SceneControls = CT.dataStore.sceneData;

    return self;

}

module.exports = SceneControlsViewModel;