﻿var MenuView = function () {

    var self = this;





}

module.exports = MenuView;