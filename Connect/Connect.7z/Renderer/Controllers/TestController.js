﻿
var TestController = (
    function (CT) {

        var self = {

        };



        return self;

    }
).call({}, CT);

module.exports = TestController;