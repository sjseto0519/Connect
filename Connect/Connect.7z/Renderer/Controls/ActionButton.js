﻿var ActionButton = function () {

    var self = this;





}

module.exports = ActionButton;