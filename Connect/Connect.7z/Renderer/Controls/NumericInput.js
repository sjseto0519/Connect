﻿var NumericInput = function () {

    var self = this;





}

module.exports = NumericInput;