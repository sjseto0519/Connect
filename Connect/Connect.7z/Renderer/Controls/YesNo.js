﻿var YesNo = function () {

    var self = this;





}

module.exports = YesNo;