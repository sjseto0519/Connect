﻿

module.exports = (function (CT) {

    var self = {
        initialize: initialize
    };

    function initialize() {
        return self;
    }

    return self;

}).call({}, CT);