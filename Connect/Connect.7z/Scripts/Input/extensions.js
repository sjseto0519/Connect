﻿require('./../../Renderer/Extensions/StringExtension.js');
require('./../../Renderer/Extensions/ObjectExtension.js');