﻿window.ko = require("./../knockout.min.js");
window._ = require("./../lodash.min.js");

window.ko.mapping = require("./../mapping.js");
window.Connect = CT = {};